package com.enotes.exception;

public class EnoteExceptionNotFound extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	 public  EnoteExceptionNotFound() {
	        super();
	    }

	    public  EnoteExceptionNotFound(String customMessage) {
	        super(customMessage);
	    }
}
