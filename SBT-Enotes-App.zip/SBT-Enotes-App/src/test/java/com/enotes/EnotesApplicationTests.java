package com.enotes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnotesApplicationTests {

	@Test
	void contextLoads() {
	}

}
